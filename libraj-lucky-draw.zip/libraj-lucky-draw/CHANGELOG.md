# LibraJ Lucky Draw — Changelog

## v1.0.0 — Initial Release
- Two-page architecture (Setup + Draw)
- Tag mapping + filtering
- Animated wheel with chime
- Shuffle, import/export, save to localStorage
- White-label support (“Your Company” branding)
- Copyright © LibraJ
